package com.example.creadorpartiturasrober;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ViewScoresActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_scores);

        // Aquí puedes implementar la lógica para mostrar las partituras guardadas
    }
}
